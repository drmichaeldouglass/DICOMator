"""Storage SOP Class UIDs"""

# Imported for backwards compatibility - deprecated in v2.3, removal v3.0
from pydicom.uid import *
